@echo off
chcp 65001 >nul
setlocal
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\DDayWidget"
set "SRC_DIR=%~dp0"

echo ==================================================
echo   Installing IMOE_DDAY v1.0...
echo ==================================================
echo.

if not exist "%SRC_DIR%IMOE_DDAY.exe" (
    echo [Error] Could not find IMOE_DDAY.exe.
    echo Please extract all files from the ZIP archive before running Install.bat.
    echo.
    pause
    exit /b 1
)

taskkill /F /IM IMOE_DDAY.exe >nul 2>&1
taskkill /F /IM DDayWidget.exe >nul 2>&1
ping -n 2 127.0.0.1 >nul

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if exist "%INSTALL_DIR%\DDayWidget.exe" del /F /Q "%INSTALL_DIR%\DDayWidget.exe" >nul 2>&1
copy /Y "%SRC_DIR%IMOE_DDAY.exe" "%INSTALL_DIR%\IMOE_DDAY.exe" >nul
if errorlevel 1 (
    echo [Error] Could not copy IMOE_DDAY.exe. Please close any running instance and retry.
    pause
    exit /b 1
)
if exist "%SRC_DIR%README.txt" copy /Y "%SRC_DIR%README.txt" "%INSTALL_DIR%\README.txt" >nul
if not exist "%INSTALL_DIR%\dday-data.json" (
    if exist "%SRC_DIR%dday-data.json" (
        copy /Y "%SRC_DIR%dday-data.json" "%INSTALL_DIR%\dday-data.json" >nul
        if exist "%SRC_DIR%dday-data.json.bak" copy /Y "%SRC_DIR%dday-data.json.bak" "%INSTALL_DIR%\dday-data.json.bak" >nul
    ) else if exist "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" (
        copy /Y "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" "%INSTALL_DIR%\dday-data.json" >nul
        if exist "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json.bak" copy /Y "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json.bak" "%INSTALL_DIR%\dday-data.json.bak" >nul
        echo [Restored] Previous D-Day data was restored from backup.
    )
)

powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $d = [Environment]::GetFolderPath('Desktop'); $smDir = [Environment]::GetFolderPath('Programs'); foreach ($old in @('OneTwoDay.lnk','하루이틀.lnk')) { Remove-Item -Path (Join-Path $d $old) -Force -ErrorAction SilentlyContinue; Remove-Item -Path (Join-Path $smDir $old) -Force -ErrorAction SilentlyContinue }; $s = $ws.CreateShortcut((Join-Path $d 'IMOE_DDAY.lnk')); $s.TargetPath = (Join-Path $env:INSTALL_DIR 'IMOE_DDAY.exe'); $s.WorkingDirectory = $env:INSTALL_DIR; $s.Save(); $sm = Join-Path $smDir 'IMOE_DDAY.lnk'; $s2 = $ws.CreateShortcut($sm); $s2.TargetPath = (Join-Path $env:INSTALL_DIR 'IMOE_DDAY.exe'); $s2.WorkingDirectory = $env:INSTALL_DIR; $s2.Save()"

echo [Done] Installed to: %INSTALL_DIR%
echo [Done] Desktop and Start Menu shortcuts (IMOE_DDAY) created.
echo.
echo Launching IMOE_DDAY...
start "" "%INSTALL_DIR%\IMOE_DDAY.exe"
pause
