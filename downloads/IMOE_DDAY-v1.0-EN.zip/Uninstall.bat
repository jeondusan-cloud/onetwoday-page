@echo off
chcp 65001 >nul
setlocal
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\DDayWidget"

echo ==================================================
echo   Uninstalling IMOE_DDAY v1.0...
echo ==================================================
echo.

taskkill /F /IM IMOE_DDAY.exe >nul 2>&1
taskkill /F /IM DDayWidget.exe >nul 2>&1
ping -n 2 127.0.0.1 >nul
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "DDayWidget" /f >nul 2>&1

powershell -NoProfile -Command "$d = [Environment]::GetFolderPath('Desktop'); $smDir = [Environment]::GetFolderPath('Programs'); foreach ($n in @('IMOE_DDAY.lnk','OneTwoDay.lnk','DDayWidget Pro.lnk','하루이틀.lnk')) { Remove-Item -Path (Join-Path $d $n) -Force -ErrorAction SilentlyContinue; Remove-Item -Path (Join-Path $smDir $n) -Force -ErrorAction SilentlyContinue }"

if exist "%INSTALL_DIR%\dday-data.json" (
    if not exist "%LOCALAPPDATA%\DDayWidget-Backup" mkdir "%LOCALAPPDATA%\DDayWidget-Backup"
    if exist "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" copy /Y "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.prev.json" >nul
    copy /Y "%INSTALL_DIR%\dday-data.json" "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" >nul
    if exist "%INSTALL_DIR%\dday-data.json.bak" copy /Y "%INSTALL_DIR%\dday-data.json.bak" "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json.bak" >nul
    echo [Backup] Your saved D-Day data was backed up to "%LOCALAPPDATA%\DDayWidget-Backup"
)

if exist "%INSTALL_DIR%" (
    rmdir /S /Q "%INSTALL_DIR%"
)

echo [Done] IMOE_DDAY has been cleanly removed.
pause
