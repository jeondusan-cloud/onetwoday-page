============================================================
  IMOE_DDAY v1.0 - Ultra-Lightweight Desktop D-Day Widget
============================================================

1. Quick Start
- Portable Mode: Double-click IMOE_DDAY.exe to launch widgets directly on your desktop.
- Windows SmartScreen Notice: Because this freeware binary is unsigned, Windows may show
  "Windows protected your PC" on first launch. Click [More info] -> [Run anyway] (100% offline).
- Install Shortcuts: Run [Install.bat] to create Desktop and Start Menu shortcuts ("IMOE_DDAY").
- Start with Windows: Right-click the [D] icon in the system tray and check "Start with Windows".

2. How to Use (Widgets Only — No Heavy Manager Window)
- Add New D-Day Widget:
  * Hover any widget and click [+] (or right-click -> + Add New D-Day Widget),
  * Or double-click the [D] tray icon / right-click tray -> + Add New D-Day Widget...
- Edit Event: Double-click any widget or click [✎] on the hover toolbar.
- Move & Resize:
  * Drag any card to snap cleanly to screen edges or adjacent widgets.
  * Drag the bottom-right corner or click [◐] to adjust Opacity and Size presets (S/M/L).
- Hover Toolbar Buttons:
  [+] New  |  [A] White/Dark Text  |  [📌] Always on Top  |  [🔓/🔒] Lock
  [◐] Opacity & Size  |  [✎] Edit  |  [✕] Delete
- Repeat / Progress Bar / Frosted Blur: Toggle via the Edit dialog or widget right-click menu.

3. Data Storage
- Automatically saved to dday-data.json next to IMOE_DDAY.exe (with automatic .bak backup).
- When placed in a read-only folder (e.g., Program Files), data is stored in %LOCALAPPDATA%\DDayWidget.

4. Uninstall & Reinstall
- Run [Uninstall.bat] to remove the app, shortcuts, and Windows startup entry cleanly.
  (Saved dday-data.json is backed up to %LOCALAPPDATA%\DDayWidget-Backup and auto-restored on reinstall.)

5. Official Page & Support
- Official Download: https://jeondusan-cloud.github.io/onetwoday-page/imoe
- Support Email: jeondusan@gmail.com
