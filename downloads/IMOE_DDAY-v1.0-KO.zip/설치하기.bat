@echo off
chcp 65001 >nul
setlocal
set "INSTALL_DIR=%LOCALAPPDATA%\Programs\DDayWidget"
set "SRC_DIR=%~dp0"

echo ==================================================
echo   IMOE_DDAY v1.0 설치를 시작합니다...
echo ==================================================
echo.

if not exist "%SRC_DIR%IMOE_DDAY.exe" (
    echo [오류] IMOE_DDAY.exe 파일을 찾을 수 없습니다.
    echo 압축(ZIP^) 파일 안에서 바로 실행하지 말고, 먼저 압축을 모두 푼 뒤 다시 실행해 주세요.
    echo.
    pause
    exit /b 1
)

taskkill /F /IM IMOE_DDAY.exe >nul 2>&1
taskkill /F /IM DDayWidget.exe >nul 2>&1
ping -n 2 127.0.0.1 >nul

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if exist "%INSTALL_DIR%\DDayWidget.exe" del /F /Q "%INSTALL_DIR%\DDayWidget.exe" >nul 2>&1
copy /Y "%SRC_DIR%IMOE_DDAY.exe" "%INSTALL_DIR%\IMOE_DDAY.exe" >nul
if errorlevel 1 (
    echo [오류] IMOE_DDAY.exe 파일을 복사하지 못했습니다. 실행 중인 프로그램을 종료한 뒤 다시 시도해 주세요.
    pause
    exit /b 1
)
if exist "%SRC_DIR%사용설명서.txt" copy /Y "%SRC_DIR%사용설명서.txt" "%INSTALL_DIR%\사용설명서.txt" >nul
if not exist "%INSTALL_DIR%\dday-data.json" (
    if exist "%SRC_DIR%dday-data.json" (
        copy /Y "%SRC_DIR%dday-data.json" "%INSTALL_DIR%\dday-data.json" >nul
        if exist "%SRC_DIR%dday-data.json.bak" copy /Y "%SRC_DIR%dday-data.json.bak" "%INSTALL_DIR%\dday-data.json.bak" >nul
    ) else if exist "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" (
        copy /Y "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json" "%INSTALL_DIR%\dday-data.json" >nul
        if exist "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json.bak" copy /Y "%LOCALAPPDATA%\DDayWidget-Backup\dday-data.json.bak" "%INSTALL_DIR%\dday-data.json.bak" >nul
        echo [복원] 이전 제거 시 백업된 일정 데이터를 복원했습니다.
    )
)

powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $d = [Environment]::GetFolderPath('Desktop'); $smDir = [Environment]::GetFolderPath('Programs'); foreach ($old in @('하루이틀.lnk','OneTwoDay.lnk')) { Remove-Item -Path (Join-Path $d $old) -Force -ErrorAction SilentlyContinue; Remove-Item -Path (Join-Path $smDir $old) -Force -ErrorAction SilentlyContinue }; $s = $ws.CreateShortcut((Join-Path $d 'IMOE_DDAY.lnk')); $s.TargetPath = (Join-Path $env:INSTALL_DIR 'IMOE_DDAY.exe'); $s.WorkingDirectory = $env:INSTALL_DIR; $s.Save(); $sm = Join-Path $smDir 'IMOE_DDAY.lnk'; $s2 = $ws.CreateShortcut($sm); $s2.TargetPath = (Join-Path $env:INSTALL_DIR 'IMOE_DDAY.exe'); $s2.WorkingDirectory = $env:INSTALL_DIR; $s2.Save()"

echo [완료] 설치 경로: %INSTALL_DIR%
echo [완료] 바탕화면 및 시작 메뉴 바로가기(IMOE_DDAY)가 생성되었습니다.
echo.
echo IMOE_DDAY를 실행합니다...
start "" "%INSTALL_DIR%\IMOE_DDAY.exe"
pause
